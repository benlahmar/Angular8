import { Component, OnInit } from '@angular/core';
import { Quiz } from '../model';
import { dataq } from './dataquiez';


@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  data= dataq;
  quiz:Quiz;
  page=0;
  constructor() { }

  ngOnInit() {
    this.quiz=new Quiz(this.data);
  }

  goto(p:number)
  {
  this.page=p;
  }
}
