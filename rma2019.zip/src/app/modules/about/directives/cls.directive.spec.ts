import { ClsDirective } from './cls.directive';

describe('ClsDirective', () => {
  it('should create an instance', () => {
    const directive = new ClsDirective();
    expect(directive).toBeTruthy();
  });
});
