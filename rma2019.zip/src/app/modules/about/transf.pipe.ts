import { Pipe, PipeTransform } from '@angular/core';
import { Quiz } from 'src/app/model';

@Pipe({
  name: 'transf'
})
export class TransfPipe implements PipeTransform {

  transform(value: Quiz, ...args: string[]): any {
    let v:any=[];
    if(args.filter(o=>o=='false').length>0)
    {
      v={id:value.id, name:value.name, desc:value.description}
    }
    let nb=args.filter(o=>o.search('q')>-1);
    console.log("**********"+args.filter(o=>o.search('q')).length);
     
     if(nb.length > 0)
     {
     let vv=nb[0];
     let vt=vv.split(':');
     v=value.questions[vt[1]];
     console.log(nb);
     }
     
      
    
    
    return v;
  }

}
