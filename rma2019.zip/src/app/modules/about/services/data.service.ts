import { Injectable } from '@angular/core';
import { Quiz } from 'src/app/model';
import { ques } from 'src/app/model/datas';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  data:Quiz;
  constructor(private http:HttpClient) {
    this.data=new Quiz(ques);
   }

   abc()
   {
    let d= this.http.get('https://jsonplaceholder.typicode.com/users')
     console.log(d);
     return d;
   }

   questiByid(id)
   {
    return  this.data.questions[id];
   }

   getuserById(id:number)
   {
    let d= this.http.get('https://jsonplaceholder.typicode.com/users/'+id)
    console.log(d);
    return d; 
   }
}
