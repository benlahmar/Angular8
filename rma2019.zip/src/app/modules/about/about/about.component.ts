import { Component, OnInit } from '@angular/core';
import { Quiz, Option } from 'src/app/model';
import {ques} from 'src/app/model/datas'

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
quiz:Quiz;
data=ques;
op:Option;
date:Date=new Date();
  constructor() { }

  ngOnInit() {
    this.quiz=new Quiz(this.data);
    this.op=this.quiz.questions[0].options[1];
  }
aa(o)
{
  o.selected=!o.selected;
  console.log(o);
}

ss(x)
{
  console.log(x);
}
}
