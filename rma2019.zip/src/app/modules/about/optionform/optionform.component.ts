import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Option } from 'src/app/model';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { stringify } from 'querystring';

@Component({
  selector: 'app-optionform',
  templateUrl: './optionform.component.html',
  styleUrls: ['./optionform.component.css']
})
export class OptionformComponent implements OnInit {

  option:Option;
  formoption :FormGroup=new FormGroup({
  name:new FormControl('v',[Validators.required,Validators.minLength(5)] ),
  id:new FormControl('',[Validators.required,Validators.min(2)]),
  isAnswer:new FormControl(false,Validators.required),

  ///questionId:new FormControl('',Validators.required)
});
@Output()
vers=new EventEmitter();
email:FormControl;
opt:FormGroup;
constructor(fb: FormBuilder) {
  this.opt = fb.group({
    hideRequired: false,
    floatLabel: 'auto'
  });
  this.email = new FormControl('', [Validators.required, Validators.email]);
}

  ngOnInit() {
    
  }


  getErrorMessage() {
    return this.formoption.controls.name.hasError('minlength') ? 'Not a valid minLength' :
    this.formoption.controls.name.hasError('required') ? 'You must enter a value' :
        
            '';

            
  }

  getErrorMsg()
  {
    return this.email.hasError('required') ? 'You must enter a value' :
    this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  envoi()
  {
      if(this.formoption.valid)
      {
        this.option=this.formoption.value;
        console.log(this.option);
        sessionStorage.setItem('data',stringify(this.option));
        this.vers.emit({'op':this.option});
      }
  }
}
