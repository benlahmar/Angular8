import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Question } from 'src/app/model';
import { ques } from 'src/app/model/datas';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-questionform',
  templateUrl: './questionform.component.html',
  styleUrls: ['./questionform.component.css']
})
export class QuestionformComponent implements OnInit {
  d;
 option;
  @Output()
  notf=new EventEmitter();
  question:Question;
  constructor(private dservice:DataService) { }

  ngOnInit() {
    this.question=new Question(this.d);
    
  }

  act()
  {
    this.notf.emit({'q':this.question});
  }

  recup(ev:Event)
  {
   this.option= ev.op;
   
   this.question.options.push(ev.op);
   console.log(this.question);
  }
}
