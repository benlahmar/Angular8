import { Component, OnInit } from '@angular/core';
import { Quiz } from 'src/app/model';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-quizform',
  templateUrl: './quizform.component.html',
  styleUrls: ['./quizform.component.css'],
  providers: []
})
export class QuizformComponent implements OnInit {

  constructor(private dservice:DataService) { }
  quiz:Quiz;
  data;
  vv;
  ds;
  ngOnInit() {
    
    this.quiz=new Quiz(this.data);
    console.log("** service***");
   console.log(this.dservice.questiByid(2));
  }
  ff()
  {
    console.log(this.quiz);
  }

  recpt(event:Event)
  {
    this.vv=event.q;
    console.log(this.vv);

    this.quiz.questions.push(this.vv);
    console.log(this.quiz);
  }

  abcd()
  {
    //this.ds=this.dservice.abc().toPromise();
    this.dservice.abc().subscribe((x)=>{this.ds=x});
    console.log(this.ds);
    //this.ds.then((rr)=>{this.ds =rr;  });
   
  }

  getuserById(id)
  {
    this.dservice.getuserById(id).subscribe((x)=>{this.ds=x});
  }

}
