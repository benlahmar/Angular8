import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AboutRoutingModule } from './about-routing.module';
import { AboutComponent } from './about/about.component';
import { ClsDirective } from './directives/cls.directive';
import {MatButtonModule} from '@angular/material/button';
import {MatStepperModule} from '@angular/material/stepper';
import {MatCardModule} from '@angular/material/card';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatBadgeModule} from '@angular/material/badge';
import { Dashb2Component } from './dashb2/dashb2.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { LayoutModule } from '@angular/cdk/layout';
import { Nav2Component } from './nav2/nav2.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { DdropComponent } from './ddrop/ddrop.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { QuizformComponent } from './quizform/quizform.component';
import { QuestionformComponent } from './questionform/questionform.component';
import { OptionformComponent } from './optionform/optionform.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { TransfPipe } from './transf.pipe';
import { DataService } from './services/data.service';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [AboutComponent, ClsDirective, Dashb2Component, Nav2Component, DdropComponent, QuizformComponent, QuestionformComponent, OptionformComponent, TransfPipe],
  imports: [
    CommonModule,
    AboutRoutingModule,
    MatButtonModule,
    MatStepperModule,
    MatCardModule,
    MatCheckboxModule,
    FormsModule,
    MatBadgeModule,
    MatGridListModule,
    MatMenuModule,
    MatIconModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    DragDropModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    HttpClientModule
  ],
  providers: [DataService]
})
export class AboutModule { }
