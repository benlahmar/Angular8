export const mydata=[{
    "slug": "aspnet",
    "title": "AspNet",
    "logo": "assets/images/aspnet.png",
    "description": "Asp.Net Quiz (contains webform, mvc, web API, etc.)"
},
{
    "slug": "typescript",
    "title": "TypeScript",
    "logo": "assets/images/typescript.png",
    "description": "description"
}, {
    "slug": "ecma",
    "title": "ECMAScript 6",
    "logo": "assets/images/js.jpg",
    "description": "description"
}, {
    "slug": "ng2",
    "title": "Angular 2",
    "logo": "assets/images/angular2.png",
    "description": "description"
}, {
    "slug": "react",
    "title": "React",
    "logo": "assets/images/react.png",
    "description": "description"
}];